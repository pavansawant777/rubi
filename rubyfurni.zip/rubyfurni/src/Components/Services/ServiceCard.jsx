import React, { useEffect } from "react";
import 'aos/dist/aos.css'
import Aos from "aos";
export default function ServiceCard(props){
   useEffect(()=>{
Aos.init();
   },[])
   return(<>
   
     <div className="col-lg-4 p-3" data-aos="flip-left" data-aos-delay="50" style={{maxHeight:"350px"}}>
      <div className="service-card bg-white shadow rounded p-4 text-center h-100 w-100">
        <div className="row">
          <div className="col-12 service-ico-box ps-3">
            <div className="ico-backg " style={{position:"relative"}}>
              <div className="ico text-dark" style={{fontSize:"45px",position:"absolute",bottom:"-5px",left:"-7px"}}>
              <i class={props.ico_class}></i>
              </div>
             
            </div>
          </div>
          <div className="col-12 text-start mt-4">
          <h4 className="service-heading">{props.heading}</h4>
          </div>
          <div className="col-12 mt-4 text-start">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae sapiente ut ntium dolore eum?</p>
        <a href={props.link} className="text-danger text-decoration-none">Learn More</a>
          </div>
        </div>
      </div>
    </div>
    </>)
}