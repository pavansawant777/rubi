import React from "react";
import ServiceCard from "./ServiceCard";
import Header from "../Header";
export default function ServicesPage(){
    return(<>
    <Header heading="Services"/>
    <div className="container  bg-white mt-5">
        <div className="row">
        <ServiceCard ico_class="fa-solid fa-clock-rotate-left" heading="Fast Service" link="#"/>
   <ServiceCard ico_class="fa-solid fa-chair" heading="Furniture" link="#"/>
   <ServiceCard ico_class="fa-solid fa-kitchen-set" heading="Kitchen trolly" link="#"/>
   <ServiceCard ico_class="fa-solid fa-clock-rotate-left" heading="Fast Service" link="#"/>
   <ServiceCard ico_class="fa-solid fa-chair" heading="Furniture" link="#"/>
   <ServiceCard ico_class="fa-solid fa-kitchen-set" heading="Kitchen trolly" link="#"/>
        </div>
    </div>

    </>)
}