import React, { useEffect } from "react";
import { NavLink } from "react-router-dom";
import 'aos/dist/aos.css'
import Aos from "aos";
export default function ProjectCard(){
    useEffect(()=>{
        Aos.init();
    },[])
    return(<>
    
   
            <div className=" w-100 float-start p-4" data-aos="zoom-in">
                <div className=" row proj-box bg-light border  h-100">
                 <div className="col-12 proj-img" style={{backgroundImage:"url('https://img.freepik.com/free-photo/mid-century-modern-living-room-interior-design-with-monstera-tree_53876-129805.jpg')"}}>
                    <div className="proj-cata bg-danger position-absolute start-0 text-light top-0 p-2"><h6>Furniutre</h6></div>
                 </div>
                 <div className="col-12 p-2">
                    <div className=" row ">
                        <div className="col-6">
                        <font className="float-start"><span className="" style={{fontSize:"13px"}}><span className="text-danger"><i class="fa-regular fa-calendar-days"></i></span>&nbsp;12 JUL</span></font>   
                        </div>
                        <div className="col-6">
                        <font className="float-end">                        <span className="" style={{fontSize:"13px"}}><span className="text-warning"><i class="fa fa-star"></i></span> <span className="text-danger">5</span>/5</span>
</font>
                        </div>

                    </div>
                    <div className="row w-100">
                        <h3>Heading</h3>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. In sit </p>
                        <div className="w-100 float-start">
                          <span style={{fontSize:"14px"}}><span className="text-danger"><i className="fa fa-user"></i></span>&nbsp;pratik chindhe</span> |  <span style={{fontSize:"14px"}}><span className="text-danger"><i className="fa fa-phone"></i></span>&nbsp;7058451982</span> <br/>
                         
                        </div>
                        <div className="w-100 mt-1">
                            <NavLink to="/projects/id" style={{fontSize:"16px"}} className="text-danger ">Show more</NavLink>
                        </div>
                    </div>
                 </div>
                </div>
            </div>
          
    </>)
}