import React from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
export default function ProjectInfo(){
    var settings = {
        autoplay: true,
      autoplaySpeed: 2000,
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        navigation:true,
        responsive: [
            {
              breakpoint: 1024,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
              },
            },
            {
              breakpoint: 768,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
              },
            },
          ],
        
      };
    return(<>
    <div className="container">
        <div className="row">
            <div className="col-lg-9 p-3">
                <div className="row  shadow">
                    <div className="col-12 p-0">
                   <Slider {...settings}>
<div className="float-start">
<img src="https://i.ytimg.com/vi/FpRq9C6C19g/hq720.jpg?sqp=-oaymwEcCNAFEJQDSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLAO_LVuab48GSlOLn7i9tQ_YRoVuw" style={{height:"450px"}} className="w-100"/>
</div>
<div className="float-start">
<img src="https://i.ytimg.com/vi/FpRq9C6C19g/hq720.jpg?sqp=-oaymwEcCNAFEJQDSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLAO_LVuab48GSlOLn7i9tQ_YRoVuw" style={{height:"450px"}} className="w-100"/>
</div>
<div className="float-start">
<img src="https://i.ytimg.com/vi/FpRq9C6C19g/hq720.jpg?sqp=-oaymwEcCNAFEJQDSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLAO_LVuab48GSlOLn7i9tQ_YRoVuw" style={{height:"450px"}} className="w-100"/>
</div>

                   </Slider>
                   
                    </div>
                    <div className="col-12 p-2 pb-4">
                        <div className="w-100">
                            <h6 style={{letterSpacing:"2px",textTransform:"uppercase",fontWeight:"400"}}>Furniture</h6>
                        </div>
                        <div className="w-100">
                            <span className="float-start">
                                <span><span className="text-danger"><i class="fa-regular fa-calendar"></i></span>&nbsp;12 Jul 2024</span>
                            </span>
                            <span className="float-end">
                                <span><span className="text-warning"><i class="fa fa-star"></i></span>&nbsp;<span className="text-danger">5</span> /5</span>
                           
                            </span>
                        </div>
                        <br/> <br/>
                        <h2>Heading for Project</h2>
                        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Facere eum nesciunt aut dolores eveniet rem assumenda harum minima, aperiam, repellendus perferendis! Distinctio aliquid molestiae quos velit repudiandae accusantium mollitia officiis.</p>
                      
                      <span><span className="text-danger"><i className="fa fa-location-dot"></i></span>&nbsp;&nbsp;  3037-Antophill ,andheri ,mumbai-414603</span><br/>
                       <button className="btn btn-danger rounded-pill mt-3">Enquire Now</button>
                    </div>
                </div>
            </div>
            <div className="col-lg-3 p-3">
                <div className="row bg-light shadow p-3">
                    <div className="col-12">
                        <h4>Client Information </h4>
                    </div>
               <div className="col-12">
                <br/>
               &nbsp;   <span className="text-start"><span className="text-danger"><i className="fa fa-user"></i></span>&nbsp;&nbsp;Pratik chindhe</span>
               </div>
               <div className="col-12 mt-1">
             
               &nbsp;   <span className="text-start"><span className="text-danger"><i className="fa fa-phone"></i></span>&nbsp;&nbsp;7058451985</span>
               </div>
               <div className="col-12 mt-1">
             
             &nbsp;   <span className="text-start"><span className="text-danger"><i className="fa fa-envelope"></i></span>&nbsp;&nbsp;pratikchindhe@gmail.com</span>
             </div>
          
                </div>
            </div>
        </div>
    </div>
    </>)
}