import React from "react";
import Header from "../Header";
import { NavLink } from "react-router-dom";
import ProjectCard from "./ProjectCard";
export default function ProjectPage(){
    return(<>
    <Header heading="Projects"/>
    <div className="container-fluid p-5">
        
        <div className="row">
        <div className="col-lg-9 p-0">
            <div className="row">
<div className="col-lg-4 p-0">
<ProjectCard/>

</div>
<div className="col-lg-4 p-0">
<ProjectCard/>

</div>
<div className="col-lg-4 p-0">
<ProjectCard/>

</div>



            </div>
            
        </div>



        {/* category */}
        <div className="col-lg-3 pt-4">
          <div className="w-100 p-2 bg-light border">
            <h3 style={{textTransform:"uppercase"}} className="text-secondary">Categories</h3>
            <ul>
                <li><NavLink className="text-secondary text-decoration-none" to="/projects">All</NavLink></li>
                <li><NavLink className="text-secondary text-decoration-none" to="/projects">Furniture</NavLink></li>
                <li><NavLink className="text-secondary text-decoration-none" to="/projects">Glass Ralining</NavLink></li>
                <li><NavLink className="text-secondary text-decoration-none" to="/projects">Steel Railing</NavLink></li>
            </ul>
          </div>
        </div>
           
        </div>
    </div>
    </>)
}