import React from "react";
import BlogCard from "../Blog/BlogCard";
import { NavLink } from "react-router-dom";
export default function BlogSection(){
    return(<>
    <div className="container p-4 mt-3">
        <div className="row">
            <div className="col-12 text-center">
                <h2 className="sec-heading"><span className="text-danger">B</span>logs</h2>
                <NavLink to="/projects" className="text-danger float-end text-decoration-none">View All</NavLink>

            </div>
        </div>
    </div>
    <div className="container-fluid p-5 bg-light">
        <div className="row">
        <BlogCard/>
        <BlogCard/>
        <BlogCard/>
        </div>
    </div>
    </>)
}