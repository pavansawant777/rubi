import Aos from "aos";
import React, { useEffect, useState } from "react";
import 'aos/dist/aos.css'
export default function EnquiryBox(){
    useEffect(()=>{
Aos.init();

    },[])
    const [formValues, setFormValues] = useState({
        name: '',
        contactNumber: '',
        workType: '',
        address: '',
      });
    
      const [errors, setErrors] = useState({});
    
      
      const nameRegex = /^[a-zA-Z\s]+$/; 
      const contactNumberRegex = /^[0-9]{10}$/; 
      const addressRegex = /^[a-zA-Z0-9\s]+$/; 
    
      
      const handleChange = (e) => {
        const { name, value } = e.target;
        setFormValues({ ...formValues, [name]: value });
      };
    
      
      const validateForm = () => {
        let formErrors = {};
    
        
        if (!nameRegex.test(formValues.name)) {
          formErrors.name = 'Name can only contain letters and spaces.';
        }
    
        
        if (!contactNumberRegex.test(formValues.contactNumber)) {
          formErrors.contactNumber = 'Contact number must be 10 digits.';
        }
    
        
        if (!formValues.workType) {
          formErrors.workType = 'Please select your work type.';
        }
    
        
        if (!addressRegex.test(formValues.address)) {
          formErrors.address = 'Address can only contain letters, numbers, and spaces.';
        }
    
        setErrors(formErrors);
    
        
        return Object.keys(formErrors).length === 0;
      };
    
    
      const handleSubmit = (e) => {
        e.preventDefault();
        if (validateForm()) {
          
          console.log('Form Submitted:', formValues);
        } else {
          console.log('Form has errors.');
        }
      };
    return(<>
     <div className="container-fluid d-none d-lg-block" id="enquiry-container">
    <div className="enquiry-box shadow rounded-4 p-3" data-aos="fade-up">
        <div className="row">
            <div className="col-md-12 text-center">
                <h4 className="mini-heading">Enquire now</h4>
            </div>
            <div className="col-md-12 mt-4">
            <form onSubmit={handleSubmit}>
              {errors.name && <span className="text-danger" style={{"fontSize":"12px"}} > <i className='fa fa-warning me-1'></i>{errors.name}</span>}
            <input
              type="text"
              name="name"
              placeholder="Your Name*"
              className="form-control rounded-0 mb-3"
              value={formValues.name}
              onChange={handleChange}
              required
            />

{errors.contactNumber && <span className="text-danger" style={{"fontSize":"12px"}}><i className='fa fa-warning me-1'></i>{errors.contactNumber}</span>}
            <input
              type="number"
              name="contactNumber"
              placeholder="Contact number*"
              className="form-control rounded-0 mb-3"
              value={formValues.contactNumber}
              onChange={handleChange}
              required
            />

{errors.workType && <span className="text-danger" style={{"fontSize":"12px"}}> <i className='fa fa-warning me-1'></i>{errors.workType}</span>}
            <select
              name="workType"
              className="form-control rounded-0 mb-3"
              value={formValues.workType}
              onChange={handleChange}
              required
            >
              <option value="" disabled>Select your work type</option>
              <option>Furniture</option>
              <option>Steel Railing</option>
              <option>Kitchen Trolly</option>
              <option>Glass Railing</option>
            </select>

            {errors.address && <span className="text-danger " style={{"fontSize":"12px"}}> <i className='fa fa-warning me-1'></i>{errors.address}</span>}
            <textarea
              name="address"
              className="form-control rounded-0 mb-4"
              placeholder="Your Address"
              rows={5}
              value={formValues.address}
              onChange={handleChange}
              required
            ></textarea>

            <button className="btn btn-outline-danger w-100 rounded-0" type="submit">Send Message</button>
          </form>
            </div>
        </div>

    </div>
    </div>
    <div className="container-fluid d-none d-md-block d-lg-none" id="enquiry-container-md">
    <div className="enquiry-box-md shadow rounded-4 p-3" data-aos="fade-up">
        <div className="row">
            <div className="col-md-12 text-center">
                <h4 className="mini-heading">Enquire now</h4>
            </div>
            <div className="col-md-12 mt-4">
            <form onSubmit={handleSubmit}>
              {errors.name && <span className="text-danger" style={{"fontSize":"12px"}} > <i className='fa fa-warning me-1'></i>{errors.name}</span>}
            <input
              type="text"
              name="name"
              placeholder="Your Name*"
              className="form-control rounded-0 mb-3"
              value={formValues.name}
              onChange={handleChange}
              required
            />

{errors.contactNumber && <span className="text-danger" style={{"fontSize":"12px"}}><i className='fa fa-warning me-1'></i>{errors.contactNumber}</span>}
            <input
              type="number"
              name="contactNumber"
              placeholder="Contact number*"
              className="form-control rounded-0 mb-3"
              value={formValues.contactNumber}
              onChange={handleChange}
              required
            />

{errors.workType && <span className="text-danger" style={{"fontSize":"12px"}}> <i className='fa fa-warning me-1'></i>{errors.workType}</span>}
            <select
              name="workType"
              className="form-control rounded-0 mb-3"
              value={formValues.workType}
              onChange={handleChange}
              required
            >
              <option value="" disabled>Select your work type</option>
              <option>Furniture</option>
              <option>Steel Railing</option>
              <option>Kitchen Trolly</option>
              <option>Glass Railing</option>
            </select>

            {errors.address && <span className="text-danger " style={{"fontSize":"12px"}}> <i className='fa fa-warning me-1'></i>{errors.address}</span>}
            <textarea
              name="address"
              className="form-control rounded-0 mb-4"
              placeholder="Your Address"
              rows={5}
              value={formValues.address}
              onChange={handleChange}
              required
            ></textarea>

            <button className="btn btn-outline-danger w-100 rounded-0" type="submit">Send Message</button>
          </form>
            </div>
        </div>

    </div>
    </div>
    <div className="container-fluid p-5 d-block d-md-none " id="enquiry-container">
    <div className="row rounded-4 shadow p-3" data-aos="fade-up">
            <div className="col-md-12 text-center rounded ">
                <div className="sec-heading-box">
                <h4 className="mini-heading">Enquire now</h4>
                </div>
            </div>
            <div className="col-md-12 mt-4">
            <form onSubmit={handleSubmit}>
              {errors.name && <span className="text-danger" style={{"fontSize":"12px"}} > <i className='fa fa-warning me-1'></i>{errors.name}</span>}
            <input
              type="text"
              name="name"
              placeholder="Your Name*"
              className="form-control rounded-0 mb-3"
              value={formValues.name}
              onChange={handleChange}
              required
            />

{errors.contactNumber && <span className="text-danger" style={{"fontSize":"12px"}}><i className='fa fa-warning me-1'></i>{errors.contactNumber}</span>}
            <input
              type="number"
              name="contactNumber"
              placeholder="Contact number*"
              className="form-control rounded-0 mb-3"
              value={formValues.contactNumber}
              onChange={handleChange}
              required
            />

{errors.workType && <span className="text-danger" style={{"fontSize":"12px"}}> <i className='fa fa-warning me-1'></i>{errors.workType}</span>}
            <select
              name="workType"
              className="form-control rounded-0 mb-3"
              value={formValues.workType}
              onChange={handleChange}
              required
            >
              <option value="" disabled>Select your work type</option>
              <option>Furniture</option>
              <option>Steel Railing</option>
              <option>Kitchen Trolly</option>
              <option>Glass Railing</option>
            </select>

            {errors.address && <span className="text-danger " style={{"fontSize":"12px"}}> <i className='fa fa-warning me-1'></i>{errors.address}</span>}
            <textarea
              name="address"
              className="form-control rounded-0 mb-4"
              placeholder="Your Address"
              rows={5}
              value={formValues.address}
              onChange={handleChange}
              required
            ></textarea>

            <button className="btn btn-outline-danger w-100 rounded-0" type="submit">Send Message</button>
          </form>
            </div>
        </div>
    </div>
    </>)
}