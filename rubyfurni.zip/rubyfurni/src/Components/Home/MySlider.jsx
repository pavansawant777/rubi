import React, { useEffect } from "react";
import 'aos/dist/aos.css'
import Aos from "aos";
export default function MySlider(){
    useEffect(()=>{
      Aos.init();
    })
    return(<>

    <div className="container-fluid d-none d-lg-block" id="slider-box">
        <div className="row">
            <div className="col-lg-12 p-0 " >
            <div id="carouselExampleAutoplaying" className="carousel slide" style={{height:"530px",overflow:"hidden"}} data-bs-ride="carousel">
  <div className="carousel-inner">
    <div className="carousel-item active">
      <img src="https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1sqF6k.img?w=549&h=309&m=6&x=379&y=56&s=53&d=53&f=webp" className="d-block w-100" alt="..." />
    </div>
    <div className="carousel-item">
      <img src="https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1sqF6k.img?w=549&h=309&m=6&x=379&y=56&s=53&d=53&f=webp" className="d-block w-100" alt="..." />
    </div>
    <div className="carousel-item">
      <img src="https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1sqF6k.img?w=549&h=309&m=6&x=379&y=56&s=53&d=53&f=webp" className="d-block w-100" alt="..." />
    </div>
  </div>
 

</div>
<div className="slider-side-cover shadow">
    <div className="row">
        <div className="col-12 ps-5 " data-aos="fade-right" id="rolling-heading">
        <div className="heading-content">
  <div className="overf">
    <h2 className="pre-text">We Make&nbsp;</h2>
    <div id="text-animate">
      <h2>Kitchen Trolly</h2>
      <h2>Steel Railing</h2>
      <h2>Glass Railing</h2>
      <h2>Furniture</h2>
    </div>
  </div>
</div>



        </div>
        <div className="col-11 ps-5 mt-5 ms-1" data-aos="fade-up">
        <h5 className="mini-heading ms-5 ">About us</h5>
        <p className="text-start ps-5 mb-4">Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias, commodi esse dolorem quam consectetur incidunt repudiandae ipsam unde! Mollitia enim voluptate reiciendis architecto sequi officiis recusandae ipsam perspiciatis distinctio dicta.</p>
        <button className="btn btn-outline-danger rounded-0 ms-5">View More</button><button className="btn btn-danger ms-1 rounded-0"><i className="fa fa-phone"></i>&nbsp;&nbsp;Contact us</button>
        </div>

    </div>
    <div className="slider-enquiry-box">

    </div>
</div>

            </div>
        </div>
    </div>



    <div className="container-fluid d-none d-md-block d-lg-none overflow-hidden" >
      <div className="row">
        <div className="col-md-12 p-0" id="res-slider">
        <div id="carouselExampleAutoplaying" className="carousel slide"  data-bs-ride="carousel">
  <div className="carousel-inner">
    <div className="carousel-item active">
      <img src="https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1sqF6k.img?w=549&h=309&m=6&x=379&y=56&s=53&d=53&f=webp" className="d-block w-100" alt="..." />
    </div>
    <div className="carousel-item">
      <img src="https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1sqF6k.img?w=549&h=309&m=6&x=379&y=56&s=53&d=53&f=webp" className="d-block w-100" alt="..." />
    </div>
    <div className="carousel-item">
      <img src="https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1sqF6k.img?w=549&h=309&m=6&x=379&y=56&s=53&d=53&f=webp" className="d-block w-100" alt="..." />
    </div>
  </div>
  
  <div className="res-slider-cover pt-5">
  
    <div className="row">
      <div className="col-12 ">
      <div className="row ps-5">
          <div className="col-5 " data-aos="fade-down" style={{position:"relative"}}>
          <div className="heading-content-sm  ">
          
  <div className="overf-sm">
  <h2 className="pre-text-sm">We Make&nbsp;</h2><br/>
    <div id="text-animate-sm">
      <h2>Kitchen Trolly</h2>
      <h2>Steel Railing</h2>
      <h2>Glass Railing</h2>
      <h2>Furniture</h2>
    </div>
  </div>
</div>
          </div>
        </div>
      </div><br/><br/>
      <div className="col-11 ps-5" data-aos="fade-top">
        <h6 className="mini-heading" style={{fontWeight:"600"}}>About us</h6>
        <p className="">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Culpa voluptatum a dolore distinctio quibusdam quos, veniam vel ipsa inventore repellendus autem eligendi illo? Ullam dolores velit a perferendis suscipit officiis!</p>
        <button className="btn btn-outline-danger rounded-0 m" >View More</button><button className="btn btn-danger ms-1 rounded-0"><i className="fa fa-phone"></i>&nbsp;&nbsp;Contact us</button>

      </div>
    </div>
  </div>
</div>
        </div>
      </div>
      
    </div>


    <div className="container-fluid d-block d-md-none d-lg-none" >
      <div className="row">
         <div className="col-12 p-1" style={{position:"relative", height:"230px",overflow:"hidden"}}>
        <div id="carouselExampleAutoplaying" className="carousel slide" style={{height:"230px"}} data-bs-ride="carousel">
  <div className="carousel-inner">
    <div className="carousel-item active">
      <img src="https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1sqF6k.img?w=549&h=309&m=6&x=379&y=56&s=53&d=53&f=webp" className="d-block w-100" alt="..." />
    </div>
    <div className="carousel-item">
      <img src="https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1sqF6k.img?w=549&h=309&m=6&x=379&y=56&s=53&d=53&f=webp" className="d-block w-100" alt="..." />
    </div>
    <div className="carousel-item">
      <img src="https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1sqF6k.img?w=549&h=309&m=6&x=379&y=56&s=53&d=53&f=webp" className="d-block w-100" alt="..." />
    </div>
  </div>



</div>
<div className="slider-cover-sm">
        <div className="row justify-content-center align-item-center">
          <div className="col-9 text-center text-light mt-4">
            <h4 style={{fontWeight:"400"}} className="mb-3" id="slider-sm-heading" data-aos="fade-down">Your Kitchen’s Best Friend.</h4>
          <p className="text-center text-light" data-aos="fade-up">Lorem ipsum dolor sit amet consectetur adipisicing elit. debitis  about it obcaecati tenetur</p>
        <button className="btn btn-outline-danger rounded-pill btn-sm" data-aos="fade-up">Read more</button>
          </div>
        </div>
        </div>
        </div> 
      </div>
     
    </div>
    </>)
}