import React, { useEffect } from "react";

import EnquiryBox from "./EnquiryBox";
import 'aos/dist/aos.css'

import Aos from "aos";
import LinkBtn from "../Other Elements/LinkBtn";
import Categories from "./Categories";
import ServiceCard from "../Services/ServiceCard";
import Serivces from "./Services";
import Projects from "./Projects";

import Slider from "react-slick";
import MySlider from "./MySlider";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import BlogCard from "../Blog/BlogCard";
import BlogSection from "./BlogSection";
export default function Home(){
  
    useEffect(()=>{
    Aos.init();
  
   
    
   
    },[])
   
    
    return(<>
    <MySlider/>
   <EnquiryBox/>
 <Categories/>
 <Serivces/>
 <Projects/>
 <BlogSection/>

  

    </>)
}