import React from "react";
import ServiceCard from "../Services/ServiceCard";
import { NavLink } from "react-router-dom";
export default function Serivces(){
    return(<>
    <div className="container p-4 mt-5">
  <div className="row">
    <div className="col-md-12 text-center">
      <h1 className="sec-heading"><span className="text-danger">S</span>ervices</h1>
      <NavLink to="/services" className="text-danger float-end text-decoration-none">View All</NavLink>

    </div>
  </div>
 </div>
 <div className="container-fluid p-5 bg-light">
  <div className="row">
   <ServiceCard ico_class="fa-solid fa-clock-rotate-left" heading="Fast Service" link="#"/>
   <ServiceCard ico_class="fa-solid fa-chair" heading="Furniture" link="#"/>
   <ServiceCard ico_class="fa-solid fa-kitchen-set" heading="Kitchen trolly" link="#"/>
  </div>
 </div>
    </>)
}