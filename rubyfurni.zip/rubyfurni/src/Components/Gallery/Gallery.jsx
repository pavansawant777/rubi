import React from "react";
import Header from "../Header";
import GalleryCard from "./GalleryCard";
export default function Gallery(){
    return(<>
    <Header heading="Gallery"></Header>
    <div className="container-fluid p-5">
        <div className="row">
        <GalleryCard gallaryHeading="Gallery"/>
        <GalleryCard gallaryHeading="Gallery"/>
        <GalleryCard gallaryHeading="Gallery"/>

        </div>
    </div>
    </>)
}