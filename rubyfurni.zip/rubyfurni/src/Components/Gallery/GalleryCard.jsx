import React, { useEffect } from "react";

import AOS from "aos";
import "aos/dist/aos.css";


export default function GalleryCard(props) {
  useEffect(() => {
    AOS.init({
      duration: 1000,  // Animation duration in milliseconds
      once: true       // Whether animation happens only once
    });
  }, []);

  return (
    <>


  

          <div className="col-lg-4 p-2">
            <div className="p-0 shadow" data-aos="fade-up">
              <div className="overflow-hidden">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT6e9s4gBygobe-QG0AulRjhxMi8eGN6kQwug&s" className="image-gallary" height={"100%"} width={"100%"} />
              </div>
              <div className="p-2">
                <h5 className="text-start">{props.gallaryHeading}</h5>
              </div>
            </div>
          </div>
         
         
   
    </>
  );
}