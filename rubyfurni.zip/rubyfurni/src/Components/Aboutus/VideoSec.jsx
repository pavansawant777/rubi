import React from "react";
export default function VideoSec(){
    return(<>
     {/*Video section */}
<div className="contianer overflow-hidden mt-5 mb-5">
    <div className="row ">
        <div className="col-12 text-center" data-aos="fade-right">
            <h2 className="sec-heading"><span className="text-danger">O</span>ur Shop</h2>
        </div>
    </div>
</div>
     <div className="container-fluid  bgvideo overflow-hidden  mt-5">

<div className="row">
  <div className="col-lg-12 p-5    "   data-aos="fade-up">
  <div class="playbtn">
<a href="https://www.youtube.com/watch?v=TGHqBX1YJRc" target="_blank">
<img src="https://i.ibb.co/1JS5h3K/play.png" alt="play" border="0"/>    
</a>
</div>
  </div>
</div>
<div className="row">
  <div className="col-lg-12 ">
    <div className="p-5 mt-t">
    <h1 className="text-center text-white" data-aos="fade-up"><b>Great Kitchenware, For any Kitchen</b></h1>
    <p className="text-center text-white "  data-aos="fade-up"> labore et dolore magna aliqua Lorem ipsum dolor sit amet consectetur adipisicing elit. Blanditiis, ut nisi? Asperiores neque odit dolor mollitia voluptatem? Optio, velit incidunt.</p>
      <div className="text-center">

    
      </div>
    </div>
  </div>
</div>
</div>

    
    </>)
}