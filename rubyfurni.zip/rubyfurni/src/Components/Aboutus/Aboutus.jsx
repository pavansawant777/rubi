import React, { useEffect } from "react";
import VideoSec from "./VideoSec";
import OurTeam from "./OurTeam";
import 'aos/dist/aos.css'
import Aos from "aos";
import Header from "../Header";

export default function Aboutus(){
useEffect(()=>{
  Aos.init();
})
return(<>
<Header heading="AboutUs"/>
         <div className="container-fluid mt-5 py-5">
  <div className="row">
    <div className="col-lg-6 p-0">
      <img
        src="https://t3.ftcdn.net/jpg/02/11/77/34/360_F_211773485_lpXiPF60jSU4xGCqPItrlvkpKvsnWQq8.jpg"
        className="railingimg h-100"
        data-aos="fade-right"
        
      />
    </div>
    <div className="col-lg-6 bg-light p-4" data-aos="fade-left">
      <div className="w-100" >
      <h1 className="text-black ">
        The Best Quality railing services Are Here
      </h1>
      <p className="mt-4">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
        veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
        commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
        velit esse cillum dolore eu fugiat nulla pariatur.
      </p>
      <p>
        {" "}
        Sed ut perspiciatis unde omnis iste natus error sit voluptatem
        accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab
        illo inventore veritatis et quasi architecto beatae vitae dicta sunt
        explicabo.
      </p>
      <div className="row">
        <div className="col-md-4 text-center">
          <span style={{ fontSize: 50 }}>
            <i className="fa-solid fa-handshake text-danger" />
          </span>
          <h4>Trusted shop</h4>
        </div>
        <div className="col-md-4 text-center">
          <span style={{ fontSize: 50 }}>
            <i className="fa-solid fa-thumbs-up text-danger" />
          </span>
          <h4>Best Quality</h4>
        </div>
        <div className="col-md-4 text-center">
          <span style={{ fontSize: 50 }}>
            <i className="fa-solid fa-indian-rupee-sign text-danger" />
          </span>
          <h4>Best price</h4>
        </div>
      </div>
      </div>
      
    </div>
  </div>
</div>


   <VideoSec/>


        
<OurTeam/>
         



    </>)
}