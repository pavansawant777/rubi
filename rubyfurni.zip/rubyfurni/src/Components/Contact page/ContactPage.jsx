import React, { useEffect, useState } from "react";
import Header from "../Header";
import 'aos/dist/aos.css'
import Aos from "aos";
export default function ContactPage(){
    useEffect(()=>{
    Aos.init();
    },[])
    const [value, setValue] = useState({
      name: '',
      email: '',
      subject: '',
      message: ''
    });
  
    const [error, setError] = useState({});
  
   
    const nameRegex = /^[a-zA-Z\s]+$/;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const subjectRegex = /^[a-zA-Z0-9\s.,!?'-]{10,}$/;
    const messageRegex = /^[a-zA-Z0-9\s.,!?'-]{10,}$/;
  
  
    const handleChange = (e) => {
      const { name, value } = e.target;
      setValue({ ...value, [name]: value });
    };
  
  
    const validateForm = () => {
      let formErrors = {};
  
  
      if (!nameRegex.test(value.name)) {
        formErrors.name = 'Enter the Valid Name.';
      }
  
      if (!emailRegex.test(value.email)) {
        formErrors.email = ' enter a valid email ';
      }
  
  
      if (!subjectRegex.test(value.subject)) {
        formErrors.subject = 'Subject must be at least 10 characters Required';
      }
  
      if (!messageRegex.test(value.message)) {
        formErrors.message = 'Message must be at least 10 characters Required';
      }
  
      setError(formErrors);
  
  
      return Object.keys(formErrors).length === 0;
    };
  
   
    const handleSubmit = (e) => {
      e.preventDefault();
      if (validateForm()) {
        console.log('Form Submitted:', value);
      } else {
        console.log('Form has errors.');
      }
    };
    return(<>
    <>
    <Header heading="ContactUs"/>
  <section >
    <div className="p-5 container-fluid mt-2">
      <div className="row">
        <div className="col-lg-3  p-3"   >
          <div className="row shadow rounded-3" data-aos="fade-up"  style={{ minHeight:"130px"}}>
            <div className="col-lg-3 text-center text-danger">
              <i
                className="fa-solid fa-map-location-dot "
                style={{ fontSize: 50, marginTop: 30 }}
              />
            </div>
            <div className="col-lg-9 pt-3 pt-lg-0">
              <div className="row">
                <div className="col-lg-12 text-center">
                  <h4>Location</h4>
                </div>
                <div className="col-lg-12 text-center">
                  <p style={{fontSize:"13px"}}>
                    PADMA NAGAR, opp. PRIME CARE HOSPITAL, Ekvira Chowk, Savedi,
                    Ahmednagar - 414003
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-lg-3  p-3">
          <div className="row shadow rounded-3" data-aos="fade-up" style={{ minHeight: 130 }}>
            <div className="col-lg-3 text-center text-danger">
              <i
                className="fa-solid fa-phone "
                style={{ fontSize: 50, marginTop: 30 }}
              />
            </div>
            <div className="col-lg-9 pt-3 pt-lg-0">
              <div className="row ">
                <div className="col-lg-12 text-center">
                  <h4>Phone</h4>
                </div>
                <div className="col-lg-12 text-center">
                  <p>+91 8446171061</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-lg-3  p-3">
          <div className="row shadow rounded-3" data-aos="fade-up" style={{ minHeight: 130 }}>
            <div className="col-lg-3 text-center text-danger">
              <i
                className="fa-regular fa-envelope"
                style={{ fontSize: 50, marginTop: 30 }}
              />
            </div>
            <div className="col-lg-9 pt-3 pt-lg-0">
              <div className="row">
                <div className="col-lg-12 text-center">
                  <h4>Email</h4>
                </div>
                <div className="col-lg-12 text-center">
                  <p>rubykitchentrolly@gmail.com</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-lg-3  p-3">
          <div className="row shadow rounded-3" data-aos="fade-up" style={{ minHeight: 130 }}>
            <div className="col-lg-3 text-center text-danger">
              <i
                className="fa-regular fa-clock"
                style={{ fontSize: 50, marginTop: 30 }}
              />
            </div>
            <div className="col-lg-9 pt-3 pt-lg-0">
              <div className="row">
                <div className="col-lg-12 text-center">
                  <h4>Opening hours</h4>
                </div>
                <div className="col-lg-12 text-center">
                  <p>9:00 AM to 11:00 PM</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section>
    <div className="container-flud mt-5 overflow-hidden mb-5">
      <div className="row">
        <div className="col-md-6">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15078.15560605116!2d74.73408001738281!3d19.127873899999997!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bdcbb5325deb105%3A0x55c9eacc5df4d567!2sPrime%20Care%20Hospital!5e0!3m2!1sen!2sin!4v1729488550471!5m2!1sen!2sin"
            className="w-100"
            height="550px"
            allowFullScreen=""
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
        <div
          className="col-md-6 d-none d-lg-block  p-5"
          style={{ position: "relative" }}
        >
          <div
            className="w-100 p-4 rounded-4 border shadow"
            style={{
              position: "absolute",
              left: "-100px",
              zIndex: 999,
              top: 45
            }}
         id="message-box" data-aos="fade-left">
      <form onSubmit={handleSubmit}>
              <fieldset>
                <h1>Leave us a message</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam, officia!</p>
                <div className="row">
                  <div className="col-md-6">
                    <input
                      type="text"
                      name="name"
                      placeholder="Your name"
                      className="form-control"
                      value={value.name}
                      onChange={handleChange}
                      required
                    />
                    {error.name && <span className="text-danger" style={{"fontSize":"14px"}}><i className="fa fa-warning"></i> {error.name}</span>}
                  </div>
                  <div className="col-md-6 ">
                    <input
                      type="text"
                      name="email"
                      placeholder="Your email"
                      className="form-control"
                      value={value.email}
                      onChange={handleChange}
                      required
                    />
                    {error.email && <span className="text-danger" style={{"fontSize":"14px"}}><i className="fa fa-warning"></i> {error.email}</span>}
                  </div>
                  <div className="col-md-12 mt-4">
                    <input
                      type="text"
                      name="subject"
                      placeholder="Subject"
                      className="form-control"
                      value={value.subject}
                      onChange={handleChange}
                      required
                    />
                    {error.subject && <span className="text-danger" style={{"fontSize":"14px"}}><i className="fa fa-warning"></i> {error.subject}</span>}
                  </div>
                  <div className="col-md-12 mt-4">
                    <textarea
                      name="message"
                      rows={5}
                      placeholder="Your message"
                      className="form-control"
                      value={value.message}
                      onChange={handleChange}
                      required
                    />
                    {error.message && <span className="text-danger" style={{"fontSize":"14px"}}><i className="fa fa-warning"></i> {error.message}</span>}
                  </div>
                  <div className="col-md-12 mt-4">
                    <button className="btn btn-danger text-light text-center contactbtn w-75" type="submit">
                      Send Message
                    </button>
                  </div>
                </div>
              </fieldset>
            </form>
             
          </div>
        </div>
        <div className="col-md-6 d-block d-lg-none">
          <div className="w-100 p-4 bg-light border shadow" data-aos="fade-right">
          <form onSubmit={handleSubmit}>
              <fieldset>
                <h1>Leave us a message</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam, officia!</p>
                <div className="row">
                  <div className="col-md-6">
                    <input
                      type="text"
                      name="name"
                      placeholder="Your name"
                      className="form-control mb-3 mb-lg-0"
                      value={value.name}
                      onChange={handleChange}
                      required
                    />
                    {error.name && <span className="text-danger" style={{"fontSize":"14px"}}><i className="fa fa-warning"></i> {error.name}</span>}
                  </div>
                  <div className="col-md-6 ">
                    <input
                      type="text"
                      name="email"
                      placeholder="Your email"
                      className="form-control"
                      value={value.email}
                      onChange={handleChange}
                      required
                    />
                    {error.email && <span className="text-danger" style={{"fontSize":"14px"}}><i className="fa fa-warning"></i> {error.email}</span>}
                  </div>
                  <div className="col-md-12 mt-4">
                    <input
                      type="text"
                      name="subject"
                      placeholder="Subject"
                      className="form-control"
                      value={value.subject}
                      onChange={handleChange}
                      required
                    />
                    {error.subject && <span className="text-danger" style={{"fontSize":"14px"}}><i className="fa fa-warning"></i> {error.subject}</span>}
                  </div>
                  <div className="col-md-12 mt-4">
                    <textarea
                      name="message"
                      rows={5}
                      placeholder="Your message"
                      className="form-control"
                      value={value.message}
                      onChange={handleChange}
                      required
                    />
                    {error.message && <span className="text-danger" style={{"fontSize":"14px"}}><i className="fa fa-warning"></i> {error.message}</span>}
                  </div>
                  <div className="col-md-12 mt-4">
                    <button className="btn btn-danger text-light text-center contactbtn w-75" type="submit">
                      Send Message
                    </button>
                  </div>
                </div>
              </fieldset>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
</>

    
    </>)
}