import React from "react";
import Navbar from "./Navbar";
import Footer from "./Footer";

import Home from "./Home/Home";
import Aboutus from "./Aboutus/Aboutus";
import {BrowserRouter as Router, Routes, Route } from "react-router-dom";
import ServicesPage from "./Services/ServicesPage";
import ProjectPage from "./Projects/ProjectPage";
import ContactPage from "./Contact page/ContactPage";
import ProjectInfo from "./Projects/ProjectInfo";
import Gallery from "./Gallery/Gallery";
import BlogPage from "./Blog/BlogPage";
export default function App(){
    return(<>
    <Router>
    <Navbar/>
        <Routes>
            <Route path="/" element={<Home/>}/>
            <Route path="/about" element={<Aboutus/>}/>
            <Route path="/services" element={<ServicesPage/>}/>
            <Route path="/projects" element={<ProjectPage/>}/>
            <Route path="/projects/:id" element={<ProjectInfo/>}/>
            <Route path="/contact" element={<ContactPage/>}/>
            <Route path="/gallery" element={<Gallery/>}/>
           <Route path="/blogs" element={<BlogPage/>}/>
        </Routes>
        <Footer/>
    </Router>
   
    


    </>)
}