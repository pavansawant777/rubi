import React from "react";
import Header from "../Header";
import BlogCard from "./BlogCard";
import { NavLink } from "react-router-dom";
export default function BlogPage(){
    return(<>
    <Header heading="Blogs"/>
    <div className="container-fluid p-5">
        <div className="row">
            <div className="col-lg-9 p-0">
<div className="row p-0">
<BlogCard/>
            <BlogCard/>
            <BlogCard/>
            <BlogCard/>
</div>
            </div>
            <div className="col-lg-3 p-2 ps-3">
                <div className="w-100 bg-light p-2">
                    <h3>Categories</h3>
                    <ul style={{listStyleType:"none"}}>
                        <li><NavLink to="/" className="text-decoration-none text-danger mb-2">All</NavLink> </li>
                        <li><NavLink to="/" className="text-decoration-none text-danger mb-2">Category 1</NavLink> </li>

                        <li><NavLink to="/" className="text-decoration-none text-danger mb-2">Category 2</NavLink> </li>

                        <li><NavLink to="/" className="text-decoration-none text-danger mb-2">Category 3</NavLink> </li>

                    </ul>
                </div>
            </div>
      
        </div>
    </div>
    
    </>)
}