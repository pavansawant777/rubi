import React, { useEffect } from "react";
import 'aos/dist/aos.css'
import Aos from "aos";
import { NavLink } from "react-router-dom";

export default function BlogCard(){
useEffect(()=>{
    Aos.init();
})
return(<>
   
    <div className="col-lg-4 p-2 p-lg-2" data-aos="fade-up">
      <div className="card rounded-0 overflow-hidden" >
        <div className="w-100  overflow-hidden" style={{position:"relative",height:"230px"}}>
        <img
          src="https://media.designcafe.com/wp-content/uploads/2024/04/21224629/small-open-kitchen-design.jpg"
          className="w-100 h-100 blog-img"
        />
         <div className="bg-danger text-light p-2 " style={{position:"absolute",left:"10px",bottom:"10px"}}>click here</div>
        </div>
       
       
        <div className="card-body">
          <h5 className="card-title mt-2">Card title</h5>
          <p className="card-text">
            Some quick example text to build on the card title and make up the
            bulk of the card's content.<br/>
            <NavLink className="text-danger text-decoration-none" to="/blog/id">View more</NavLink>
          </p>
         <div className="w-100">
            <span className="float-start" ><span><i className="fa-regular fa-heart"></i></span>&nbsp;1 Likes</span>
            <span className="float-end" ><span><i className="fa-regular fa-clock"></i></span>&nbsp;1 min ago</span>

         </div>
        </div>
      </div>
    </div>
   
  

    </>)
}