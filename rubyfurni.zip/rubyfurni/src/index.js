import React from "react";
import ReactDom from 'react-dom';
import App from "./Components/App";
import "./style.css"
import "./footerstyle.css"
import "./headingcss.css"
import "./AboutStyle.css"
import "./OurTeam.css"
ReactDom.render(<>
<App/>
</>,document.getElementById('root'))